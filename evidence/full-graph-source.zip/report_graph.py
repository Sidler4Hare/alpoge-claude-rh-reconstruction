import argparse
from array import array
from collections import Counter
import csv
import gzip
import json
from pathlib import Path
import sqlite3
import struct
import subprocess

ALLOWED = {"propext", "Classical.choice", "Quot.sound"}
ROOT = "riemannHypothesis"
TARGETS = [
    "RiemannHypothesis", "rhOfAll", "allChi", "critAll", "claimAll",
    "Formalism.VW.rh_of_every", "Formalism.VW.rh_of_right", "Formalism.VW.critLine",
    "UpperTheory.FinalTheorems.everyCharacter",
    "UpperTheory.FinalTheorems.everyCharacter_of_row",
    "UpperTheory.Gal.Int.galoisLocalGlobalStrong_recParameter",
    "UpperTheory.One.vwin_of_row",
    "UpperTheory.One.Join.automorphic_window_of_inputs",
    "UpperTheory.V.v_window_of_literal_automorphy_n",
    "UpperTheory.V.HV.vwin_of_counts",
    "UpperTheory.V.Win.window1",
    "UpperTheory.V.Z.J.count_i_of_printed_bound_k_kato_automorphy",
    "UpperTheory.V.HV.DescentVanishingReductions.countII_and_countIII_of_printsH_of_sp4In",
    "UpperTheory.V.Z.J.count_v_of_printed_bound_k_reduced_unitary_lift",
    "UpperTheory.LiteratureTheorems.every_character_of_literature_of_vWin",
    "UpperTheory.Lit.every_character_of_theta_integrals_local_matching",
    "UpperTheory.Top.every_character_of_green_v_win",
    "UpperTheory.Top.zero_free_all_of_green_v_win",
    "UpperTheory.Top.shape_closed_link_n_of_green",
    "UpperTheory.Top.zeroFreeAll_of_topG",
    "UpperTheory.Top.imprimitive",
    "UpperTheory.Top.supplyChi",
    "UpperTheory.Top.winPairs",
    "QH.pair_exists",
    "GlobalTheory.EX.exists_ranks_rankVal_frame",
    "Formalism.HC.zeroFreeOn_of_tiedWin_cyc",
    "Formalism.HC.level_of_tiedWin",
    "UpperTheory.Comparison₂.level_gm_le_on_family_scales",
    "Deduction.zeroFree_of_rpow_window",
    "Deduction.lemmaL",
    "Deduction.landau_window",
    "Deduction.ch_balance", "Deduction.ch_core", "Deduction.ch_top",
    "UpperTheory.Comparison₂.core_gm", "Deduction.poleData",
    "Deduction.landau_tails", "Deduction.landau_nearest", "Deduction.landau_window_key",
    "Formalism.L2.G.Adm2InU.admissible_off_twist_places", "Formalism.HN.SlopeIneq",
    "SelfIntersectionVolumeEstimates.topCovolSlim2_use_alt_alt",
    "GlobalTheory.Top.wire_sel_alt", "Formalism.L2.DIV.WordFacts",
    "Formalism.L2.Col.recChain_K_emb",
    "PositivityTheory.QuaternionShaBounds.sSha", "UpperTheory.V.ZK.sFinal",
    "PositivityTheory.ThKR.theoremK_head2",
    "GlobalTheory.T.firstOccurrenceRule_thetaChainStep_both_directions",
    "GlobalTheory.T.thetaLiftChain_onto_cuspForms_of_innerProduct",
    "Formalism.MainNotions.GL3Theta.lift_formula",
    *sorted(ALLOWED),
]
REFERENCES = {
    ROOT: 1_478_219,
    "Formalism.DivisionValues.divisor_inequality_explicit": 16_733,
    "UpperTheory.V.LemmaK": 39_607,
    "Deduction.landau_window": 50_405,
    "Formalism.VW.rh_of_every": 54_775,
    "Formalism.VW.critLine": 56_213,
    "UpperTheory.Top.imprimitive": 56_300,
}
MODE = ["type", "value", "structure"]
NIL = 0xffffffff
NAME = 1 << 31


def report(folder, output, exe, sample=False, reuse=False):
    output.mkdir(parents=True, exist_ok=True)
    if not sample and not (folder / "unpacked-ok.txt").is_file():
        raise RuntimeError("Require verified unpacked MIT export")
    with sqlite3.connect(folder / "symbols.sqlite") as db:
        symbols = {i: (name, kind, safety) for i, name, kind, safety in
                   db.execute("SELECT id,name,tag,safety FROM symbol")}
        root_name = "Classical.em" if sample else ROOT
        targets = ["Eq", "Eq.refl", "Nat.rec", *sorted(ALLOWED)] if sample else TARGETS
        reference = {} if sample else REFERENCES
        names = [root_name, *(n for n in reference if n != root_name)]
        # Resolve only requested names so display names of unrelated declarations may repeat.
        requested = {}
        for name in dict.fromkeys([*names, *targets]):
            rows = db.execute("SELECT id FROM symbol WHERE name=?", (name,)).fetchall()
            if len(rows) > 1:
                raise ValueError(f"Ambiguous target: {name} ({rows})")
            if rows:
                requested[name] = rows[0][0]
        type_id, value_id = db.execute(
            "SELECT type_id,value_id FROM symbol WHERE id=?", (requested[root_name],)
        ).fetchone()
    work = folder / "walk"
    work.mkdir(exist_ok=True)
    walks = {name: work / (str(requested[name]) + ".bin") for name in names if name in requested}
    if reuse:
        missing = [str(p) for p in walks.values() if not p.is_file()]
        if missing:
            raise RuntimeError("Missing saved BFS: " + ", ".join(missing))
    else:
        subprocess.run(
            [str(exe.resolve()), "walk", *(f"{requested[n]}={p.resolve()}" for n,p in walks.items())],
            cwd=folder, check=True,
        )

    summary = {"root": root_name, "root_id": requested[root_name], "export_declarations": len(symbols), "walks": {}}
    with (folder / "expr.bin").open("rb") as expr:
        for section, expr_id in (("root_direct_type", type_id), ("root_direct_value", value_id)):
            expr.seek(12 * expr_id)
            slot, second, third = struct.unpack("<III", expr.read(12))
            summary[section] = symbols[slot & ~NAME][0] if NAME <= slot < NIL and second == third == NIL else None
    if not sample and (summary["root_direct_type"], summary["root_direct_value"]) != ("RiemannHypothesis", "rhOfAll"):
        raise RuntimeError("Root type/value differs from the published Main.lean entry point")

    max_id = max(symbols)
    parent = array("I", [NIL]) * (max_id + 1)
    depth = array("I", [0]) * (max_id + 1)
    incoming = bytearray(max_id + 1)
    for name in names:
        if name not in walks:
            summary["walks"][name] = {"present": False, "lumi_count": reference.get(name)}
            continue
        path = walks[name]
        walk = {"constants": 0, "axioms": [], "unsafe": [], "partial": []}
        modes = Counter()
        full_tree = name == root_name
        out_path = output / ("sample-tree.tsv.gz" if sample else "rh-dependency-tree.tsv.gz")
        if full_tree:
            # Use mtime=0 so an identical export reproduces the same gzip bytes.
            raw = out_path.open("wb")
            gz = gzip.GzipFile(filename="", fileobj=raw, mode="wb", compresslevel=5, mtime=0)
            from io import TextIOWrapper
            out = TextIOWrapper(gz, encoding="utf-8", newline="")
            writer = csv.writer(out, delimiter="\t", lineterminator="\n")
            writer.writerow(["id", "declaration", "kind", "parent_id", "parent", "via", "depth"])
        try:
            for i, ancestor, label in struct.iter_unpack("<IIB", path.read_bytes()):
                declaration, kind, safety = symbols[i]
                walk["constants"] += 1
                if kind == "axiom":
                    walk["axioms"].append(declaration)
                if safety in ("unsafe", "partial"):
                    walk[safety].append(declaration)
                mode = "root" if i == ancestor else MODE[label]
                modes[mode] += 1
                if full_tree:
                    if i != ancestor and parent[ancestor] == NIL:
                        raise RuntimeError(f"BFS parent missing for {i}")
                    parent[i] = ancestor
                    depth[i] = (depth[ancestor] + 1) if i != ancestor else 0
                    incoming[i] = label
                    writer.writerow((i, declaration, kind, ancestor, symbols[ancestor][0], mode, depth[i]))
        finally:
            if full_tree:
                out.close()
                raw.close()
        walk["axioms"].sort()
        walk["modes"] = dict(modes)
        walk["present"] = True
        if name in reference:
            walk["lumi_count"] = reference[name]
            walk["delta_from_lumi"] = walk["constants"] - reference[name]
        summary["walks"][name] = walk
        print(name, walk["constants"], walk["axioms"], walk.get("delta_from_lumi"), flush=True)

    summary["landmarks"] = []
    with (output / "rh-shortest-paths.tsv").open("w", encoding="utf8", newline="") as f:
        out = csv.writer(f, delimiter="\t", lineterminator="\n")
        out.writerow(["target", "status", "step", "from", "via", "to"])
        for target in targets:
            i = requested.get(target)
            status = "absent from export" if i is None else (
                "exported, unreachable" if parent[i] == NIL else "reached")
            length = None if status != "reached" else depth[i]
            summary["landmarks"].append({"target": target, "id": i, "status": status, "distance": length})
            if length is None or not length:
                out.writerow([target, status, "", "", "", ""])
                continue
            chain = []
            while i != parent[i]:
                ancestor = parent[i]
                chain.append((symbols[ancestor][0], MODE[incoming[i]], symbols[i][0]))
                i = ancestor
            for step, (start, via, end) in enumerate(reversed(chain), 1):
                out.writerow([target, status, step, start, via, end])

    if not sample:
        summary["sha256"] = (folder / "unpacked-ok.txt").read_text(encoding="ascii").splitlines()
    (output / "rh-walk-summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    if not sample and set(summary["walks"][ROOT]["axioms"]) != ALLOWED:
        raise RuntimeError("Reached axioms differ from the three standard axioms")


if __name__ == "__main__":
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--sample", action="store_true")
    parser.add_argument("--reuse", action="store_true", help="reuse BFS records for the same scanned export")
    parser.add_argument("--exe", type=Path, default=base / "graph/target/release/rhproofgraph.exe")
    args = parser.parse_args()
    report(args.folder, args.output, args.exe, args.sample, args.reuse)


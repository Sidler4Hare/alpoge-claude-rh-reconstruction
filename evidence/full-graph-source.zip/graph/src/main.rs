use memmap2::Mmap;
use std::{
    env,
    fs::{self, File},
    io::{self, BufRead, BufReader, BufWriter, Read, Write},
    time::Instant,
};
const NIL: u32 = u32::MAX;
const NAME: u32 = 1 << 31;
fn field(s: &str, key: &str) -> u32 {
    let start = s
        .find(key)
        .unwrap_or_else(|| panic!("missing {key}: {}", &s[..s.len().min(120)]))
        + key.len();
    let mut n: u32 = 0;
    let mut found = false;
    for b in s.as_bytes()[start..].iter().copied() {
        if !b.is_ascii_digit() {
            break;
        }
        n = n
            .checked_mul(10)
            .and_then(|v| v.checked_add((b - b'0') as u32))
            .unwrap();
        found = true;
    }
    assert!(found && n < NAME);
    n
}
fn scan() -> io::Result<()> {
    let mut rows = BufReader::with_capacity(2 << 20, io::stdin().lock());
    let mut nodes = BufWriter::with_capacity(2 << 20, File::create("expr.bin")?);
    let mut meta = BufWriter::with_capacity(2 << 20, File::create("dict.ndjson")?);
    let mut count = 0u32;
    let mut s = String::new();
    let when = Instant::now();
    loop {
        s.clear();
        if rows.read_line(&mut s)? == 0 {
            break;
        }
        let first = s.split_once(':').unwrap().0;
        match first {
            "{\"in\"" | "{\"def\"" | "{\"thm\"" | "{\"opaque\"" | "{\"quot\"" | "{\"axiom\""
            | "{\"inductive\"" | "{\"meta\"" => {
                meta.write_all(s.as_bytes())?;
                continue;
            }
            "{\"il\"" => continue,
            _ => {}
        }
        let idx = field(&s, "\"ie\":");
        assert_eq!(idx, count);
        let tag = if first == "{\"ie\"" {
            s.split_once(',').unwrap().1.split_once(':').unwrap().0
        } else {
            &first[1..]
        };
        let v = match tag {
            "\"bvar\"" | "\"sort\"" | "\"natVal\"" | "\"strVal\"" => [NIL; 3],
            "\"const\"" => [NAME | field(&s, "\"name\":"), NIL, NIL],
            "\"app\"" => [field(&s, "\"fn\":"), field(&s, "\"arg\":"), NIL],
            "\"lam\"" | "\"forallE\"" => [field(&s, "\"type\":"), field(&s, "\"body\":"), NIL],
            "\"letE\"" => [
                field(&s, "\"type\":"),
                field(&s, "\"value\":"),
                field(&s, "\"body\":"),
            ],
            "\"mdata\"" => [field(&s, "\"expr\":"), NIL, NIL],
            "\"proj\"" => [field(&s, "\"struct\":"), NIL, NIL],
            _ => panic!("unrecognized expression {}", &s[..s.len().min(160)]),
        };
        let mut row = [0u8; 12];
        for (i, p) in v.iter().copied().enumerate() {
            assert!(p >= NAME || p < count);
            row[4 * i..4 * i + 4].copy_from_slice(&p.to_le_bytes());
        }
        nodes.write_all(&row)?;
        count += 1;
        if count % 100000000 == 0 {
            eprintln!(
                "parsed {count} expressions in {:.1}s",
                when.elapsed().as_secs_f64()
            );
        }
    }
    nodes.flush()?;
    meta.flush()?;
    eprintln!("{count} expressions, {:.1}s", when.elapsed().as_secs_f64());
    Ok(())
}
fn word(b: &[u8], p: usize) -> u32 {
    u32::from_le_bytes(b[p..p + 4].try_into().unwrap())
}
struct Graph<'a> {
    expr: &'a [u8],
    cells: Vec<(u32, u32)>,
    edges: Vec<u32>,
}
impl<'a> Graph<'a> {
    fn load(expr: &'a [u8]) -> io::Result<Self> {
        let mut raw = Vec::new();
        File::open("roots.bin")?.read_to_end(&mut raw)?;
        let mut cells = Vec::new();
        let mut edges = Vec::new();
        let mut p = 0;
        while p < raw.len() {
            let id = word(&raw, p) as usize;
            let n = word(&raw, p + 4);
            p += 8;
            if cells.len() <= id {
                cells.resize(id + 1, (0, 0));
            }
            assert_eq!(cells[id].1, 0);
            cells[id] = (edges.len() as u32, n);
            for _ in 0..n {
                edges.push(word(&raw, p));
                p += 4;
            }
        }
        Ok(Self { expr, cells, edges })
    }
    fn walk(&self, root: u32, path: &str) -> io::Result<()> {
        let ne = self.expr.len() / 12;
        let mut seen = vec![0u64; ne.div_ceil(64)];
        let mut pred = vec![NIL; self.cells.len()];
        let mut kind = vec![0u8; self.cells.len()];
        let mut q = vec![root];
        pred[root as usize] = root;
        let mut take = 0;
        let mut stack = Vec::new();
        let mut touched = 0usize;
        let tm = Instant::now();
        while take < q.len() {
            let owner = q[take];
            take += 1;
            let (start, n) = self.cells[owner as usize];
            assert!(n >= 2, "missing {owner}");
            for i in 0..n {
                stack.push(self.edges[(start + i) as usize]);
                while let Some(x) = stack.pop() {
                    if x == NIL {
                        continue;
                    }
                    if x >= NAME {
                        let id = (x & !NAME) as usize;
                        if pred[id] == NIL {
                            pred[id] = owner;
                            kind[id] = i.min(2) as u8;
                            q.push(id as u32);
                        }
                        continue;
                    }
                    let node = x as usize;
                    let bit = 1u64 << (node % 64);
                    let marker = &mut seen[node / 64];
                    if *marker & bit != 0 {
                        continue;
                    }
                    *marker |= bit;
                    touched += 1;
                    let off = 12 * node;
                    for k in (0..3).rev() {
                        let next = word(self.expr, off + 4 * k);
                        if next != NIL {
                            stack.push(next)
                        }
                    }
                }
            }
            if take % 200000 == 0 {
                eprintln!(
                    "walked {take} declarations, {touched} expressions, {:.1}s",
                    tm.elapsed().as_secs_f64()
                );
            }
        }
        let mut f = BufWriter::new(File::create(path)?);
        for id in q.iter().copied() {
            f.write_all(&id.to_le_bytes())?;
            f.write_all(&pred[id as usize].to_le_bytes())?;
            f.write_all(&[kind[id as usize]])?;
        }
        f.flush()?;
        println!(
            "root {root}, {} declarations, {touched} expressions in {:.1}s",
            q.len(),
            tm.elapsed().as_secs_f64()
        );
        Ok(())
    }
}
fn main() -> io::Result<()> {
    let args: Vec<_> = env::args().collect();
    if args[1] == "scan" {
        return scan();
    }
    let f = File::open("expr.bin")?;
    let map = unsafe { Mmap::map(&f)? };
    assert_eq!(map.len() % 12, 0);
    let g = Graph::load(&map)?;
    for s in &args[2..] {
        let (id, path) = s.split_once('=').unwrap();
        g.walk(id.parse().unwrap(), path)?;
    }
    fs::metadata("roots.bin")?;
    Ok(())
}

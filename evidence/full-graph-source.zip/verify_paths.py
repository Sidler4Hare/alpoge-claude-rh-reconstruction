from pathlib import Path
from array import array
from collections import defaultdict
import argparse
import mmap
import struct
import json

NIL = 0xffffffff
NAME = 1 << 31


def verify(folder, summary_path):
    summary = json.loads(summary_path.read_text(encoding="utf8"))
    with (folder / "roots.bin").open("rb") as rf, \
         (folder / "expr.bin").open("rb") as ef, \
         mmap.mmap(rf.fileno(), 0, access=mmap.ACCESS_READ) as roots, \
         mmap.mmap(ef.fileno(), 0, access=mmap.ACCESS_READ) as expr:
        walk = folder / "walk" / f"{summary['root_id']}.bin"
        data = walk.read_bytes()
        root, _, _ = struct.unpack_from("<IIB", data)
        assert root == summary["root_id"]
        reached_count = summary["walks"][summary["root"]]["constants"]
        assert len(data) == 9 * reached_count
        selected = [row["id"] for row in summary["landmarks"] if row["status"] == "reached"]
        max_id = max(node for node, _, _ in struct.iter_unpack("<IIB", data))
        parent = array("I",[NIL]) * (max_id+1)
        via = bytearray(max_id+1)
        for node, prev, kind in struct.iter_unpack("<IIB", data):
            parent[node] = prev
            via[node] = kind

        checks = defaultdict(set)
        for node in selected:
            while node != root:
                prev, kind = parent[node], via[node]
                assert prev != NIL
                checks[prev,kind].add(node)
                node = prev

        remaining = {}
        for (owner, kind), expected in checks.items():
            remaining.setdefault(owner, {})[kind] = expected
        offset = 0
        verified = 0
        while offset < len(roots) and remaining:
            owner, n = struct.unpack_from("<II", roots, offset)
            offset += 8
            specs = remaining.pop(owner, None)
            if specs:
                ns = struct.unpack_from(f"<{n}I", roots, offset)
                for mode, expected in specs.items():
                    stack = list(ns[2:] if mode == 2 else ns[mode:mode+1])
                    targets = expected.copy()
                    visited = set()
                    while stack and targets:
                        node = stack.pop()
                        if node == NIL:
                            continue
                        if node & NAME:
                            targets.discard(node & ~NAME)
                        elif node not in visited:
                            visited.add(node)
                            stack.extend(struct.unpack_from("<III", expr, 12 * node))
                    if targets:
                        raise ValueError(f"Missing direct dependencies from {owner} in mode {mode}: {targets}")
                    verified += len(expected)
            offset += 4 * n
        assert not remaining
    print(f"Independently checked {verified} unique selected direct edges from {len(selected)} reached landmarks")
    return verified


if __name__ == "__main__":
    args = argparse.ArgumentParser()
    args.add_argument("folder",type=Path)
    args.add_argument("summary",type=Path)
    ns = args.parse_args()
    verify(ns.folder,ns.summary)


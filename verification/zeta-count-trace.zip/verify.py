"""Verify proof-value edges against original Lean export records and optional external files."""

import argparse
import bisect
import csv
import gzip
import hashlib
import json
import re
import subprocess
import tempfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
TREE_SHA = "09fe6c27429a1d2f7cb7ef638e208f698d3b2ebe139c8e9549f1580ee3655804"
MANIFEST_SHA = "292caa386a620d935cfc736b56fcceaab9fe7073086693b62e899c1ee4725f04"
EXPORT_SHA = "61a8938ad5f5e57397c1c0e3b954916af546d9004ade01c3555744a681b05381"
UNPACKED_SHA = "5ea74b912147c5c93cc2b6d70cc727cf908df2f62ac6a20480a3fa02f6be244e"
EXPR_FIELDS = {
    "app": ("fn", "arg"), "lam": ("type", "body"), "forallE": ("type", "body"),
    "letE": ("type", "value", "body"), "mdata": ("expr",), "proj": ("struct",)
}


def check(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def table(filename):
    with (HERE / filename).open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def expression_records(edges, declared):
    check(len(declared) == 96 and len(edges) == 99 and
          len({(e["parent"], e["child"]) for e in edges}) == len(edges),
          "complete declaration and distinct edge tables")
    check(digest(HERE / "export-records.ndjson.gz") ==
          "c152ebb2a5fdefebedfaa1ef1ed836cb65ee8fd768e67a1ca16ea315ab6a9185",
          "serialized proof-record package SHA-256")
    with gzip.open(HERE / "export-records.ndjson.gz", "rb") as stream:
        raw = {line.rstrip(b"\n") for line in stream}
    names, expressions, bindings = {}, {}, {}
    for line in raw:
        row = json.loads(line)
        if "in" in row:
            names[row["in"]] = row
        elif "ie" in row:
            expressions[row["ie"]] = row
        else:
            kind, binding = next(iter(row.items()))
            bindings[binding["name"]] = (kind, binding)
    def full_name(i):
        labels = []
        while i:
            part = names[i]
            component = part.get("str", part.get("num"))
            labels.append(component.get("str", str(component.get("i"))))
            i = component["pre"]
        return ".".join(reversed(labels))
    check(len(raw) == 2935 and len(bindings) == 95, "complete raw record and binding set")
    for n, d in declared.items():
        i = int(d["name_id"])
        check(full_name(i) == n, n)
        if d["kind"] != "ctor":
            check(i in bindings, ("absent declaration record", n))
            kind, binding = bindings[i]
            check((kind, binding["type"], binding["value"]) ==
                  (d["kind"], int(d["type_root"]), int(d["value_root"])), n)
    num_paths = 0
    for edge in edges:
        parent, child = edge["parent"], edge["child"]
        check(edge["export_expression_path"], ("absent direct value path", parent, child))
        _, binding = bindings[int(declared[parent]["name_id"])]
        path = [int(i) for i in edge["export_expression_path"].split()]
        check(path[0] == binding["value"], parent)
        for i, j in zip(path, path[1:]):
            row = expressions[i]
            children = [row[tag][field] for tag, fields in EXPR_FIELDS.items()
                        if tag in row for field in fields]
            check(j in children, (parent, child, i, j))
        leaf = expressions[path[-1]]["const"]["name"]
        check(leaf == int(declared[child]["name_id"]), (parent, child))
        num_paths += 1
    print(f"{num_paths} kernel-expression paths, {len(raw)} original records, {len(declared)} resolved names")
    return raw, sorted(names), sorted(expressions), sorted(bindings)


def tree_edges(tree, edges, declared):
    check(digest(tree) == TREE_SHA, "whole-export RH tree SHA-256")
    found = {}
    with gzip.open(tree, "rt", encoding="utf-8", newline="") as stream:
        for row in csv.DictReader(stream, delimiter="\t"):
            if row["declaration"] in declared:
                found[row["declaration"]] = row
    for n, d in declared.items():
        row = found[n]
        check((row["id"], row["depth"], row["parent"], row["via"]) ==
              (d["name_id"], d["RH_tree_depth"], d["RH_tree_parent"], d["RH_tree_via"]), n)
    for edge in edges:
        row = found[edge["child"]]
        matched = row["parent"] == edge["parent"] and row["via"] == "value"
        check(matched == (edge["direct_in_original_RH_tree"] == "yes"), edge)
    print(f"{len(found)} names in the original RH tree, {sum(e['direct_in_original_RH_tree'] == 'yes' for e in edges)} matching direct value edges")


def source_files(workspace, declared):
    seen = {}
    for row in declared.values():
        if not row["source"]:
            continue
        path = workspace / row["source"]
        if path not in seen:
            data = path.read_bytes()
            seen[path] = hashlib.sha256(data).hexdigest(), data.decode("utf-8").splitlines()
        sha, lines = seen[path]
        check(sha == row["source_sha256"], path)
        line = int(row["line"])
        suffix = row["name"].rsplit(".", 1)[-1]
        check(suffix in lines[line-1], (path, line, suffix))
    print(f"{len(seen)} original Lean source files matched, including declaration lines")


def original_modules(cache, edges, declared):
    manifest = cache / "modules.jsonl.gz"
    check(digest(manifest) == MANIFEST_SHA, "community-build manifest SHA-256")
    modules = {r["module"]: r for r in table("modules.tsv")}
    with gzip.open(manifest, "rt", encoding="utf-8") as stream:
        next(stream)
        official = {n: (key, fn, sha) for n, key, fn, sha in map(json.loads, stream) if n in modules}
    exe = cache / "lean-4.33.1-windows/bin"
    version = subprocess.check_output([exe / "lean.exe", "--version"], text=True).strip()
    check("819816b2e0a3bf405af45ae5c7af2491d8f5bee6" in version, version)
    with tempfile.TemporaryDirectory() as temp_dir:
        temp = Path(temp_dir)
        jobs, objects = [], {}
        for n, m in modules.items():
            check(official[n] == (m["dependency_hash"], m["artifact"], m["artifact_sha256"]), n)
            archive = cache / "objects" / m["artifact"]
            check(digest(archive) == m["artifact_sha256"], archive)
            rel = Path(*n.split(".")).with_suffix(".olean")
            dirs = [temp / k / rel.parent for k in ("lib", "ir")]
            for d in dirs:
                d.mkdir(parents=True, exist_ok=True)
            jobs.append({"file": str(archive), "hash": m["dependency_hash"], "base": list(map(str, dirs))})
            objects[n] = dirs[0] / rel.name
        subprocess.run([exe / "leantar.exe", "--jobs", "3", "-f", "-x", "-j", "-"],
                       input=json.dumps(jobs).encode(), check=True)
        for n, obj in objects.items():
            check(digest(obj) == modules[n]["olean_sha256"], obj)
        plan = temp / "plan.tsv"
        plan.write_text("".join(n+"\t"+str(p)+"\n" for n,p in objects.items()), encoding="utf-8")
        dest = temp / "references.ndjson"
        subprocess.run([exe / "lean.exe", "--run", HERE / "ReadEdges.lean", plan, dest], check=True)
        parents = {r["parent"] for r in edges}
        with dest.open(encoding="utf-8") as stream:
            refs = {r["name"]: r for r in map(json.loads, stream) if r["name"] in parents}
        for edge in edges:
            parent = edge["parent"]
            row = refs[parent]
            check(row["owner"] == declared[parent]["olean_owner"], parent)
            check(edge["direct_in_original_olean_value"] == "yes" and edge["child"] in row["value"], edge)
    print(f"{version}\n{len(edges)} direct value edges in {len(modules)} original modules")


def authenticate_archive(archive, data):
    import zstandard
    raw, nids, eids, dids = data
    missing = set(raw)
    decl = re.compile(rb'\{"(?:thm|def|opaque)":\{"all":\[(?:' +
                      b"|".join(str(n).encode() for n in dids) + rb')\],[^\n]*')
    packed, unpacked = hashlib.sha256(), hashlib.sha256()
    def overlaps(block, prefix, ids):
        first = block.find(prefix)
        if first < 0:
            return False
        def at(pos):
            pos += len(prefix)
            return int(re.match(rb"\d+", block[pos:pos+22])[0])
        a = at(first)
        b = at(block.rfind(prefix))
        return bisect.bisect_left(ids, a) < bisect.bisect_right(ids, b)
    class Packed:
        def __init__(self, stream):
            self.stream = stream
        def read(self, size):
            block = self.stream.read(size)
            packed.update(block)
            return block
    total, tail = 0, b""
    with archive.open("rb") as source, zstandard.ZstdDecompressor(max_window_size=1 << 30).stream_reader(Packed(source)) as stream:
        while block := stream.read(8 << 20):
            total += len(block)
            unpacked.update(block)
            block = tail + block
            last = block.rfind(b"\n") + 1
            tail, block = block[last:], block[:last]
            if overlaps(block, b'"ie":', eids) or overlaps(block, b'{"in":', nids):
                for line in block.splitlines():
                    missing.discard(line)
            else:
                for m in decl.finditer(block):
                    missing.discard(m[0])
    check((packed.hexdigest(), unpacked.hexdigest(), total, tail) ==
          (EXPORT_SHA, UNPACKED_SHA, 61570595788, b""), "complete source archive and stream digests")
    check(not missing, ("unmatched source records", len(missing)))
    print(f"{len(raw)} exact source records authenticated in {total} uncompressed bytes")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tree", type=Path, help="published rh-dependency-tree.tsv.gz")
    parser.add_argument("--sources", type=Path, help="workspace containing the original lean/src tree")
    parser.add_argument("--cache", type=Path, help="directory with the pinned Windows Lean, LTARs and modules.jsonl.gz")
    parser.add_argument("--archive", type=Path, help="authenticate records against the complete solution.ndjson.zst")
    args = parser.parse_args()
    declared = {r["name"]: r for r in table("declarations.tsv")}
    edges = table("proof-edges.tsv")
    data = expression_records(edges, declared)
    if args.tree:
        tree_edges(args.tree, edges, declared)
    if args.sources:
        source_files(args.sources, declared)
    if args.cache:
        original_modules(args.cache, edges, declared)
    if args.archive:
        authenticate_archive(args.archive, data)

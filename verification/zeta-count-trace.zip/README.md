# Original proof values of the two deformation counts

Sections 5.23 and 14.1 of the accompanying paper give the mathematical specialization and verification scope. Extract this archive into a directory and run the following command there with Python 3.11 or later.

    python verify.py

The self-contained check reconstructs all 99 selected expression paths in the original serialized values from 2,935 exact export records. The package identifies 96 declarations in the classical RH dependency tree, including 95 original definition or theorem bindings and the conjunction constructor. The columns in proof-edges.tsv distinguish raw paths, immediate edges of that tree and direct references in the original compiled values. Every selected reference is independently present in the 24 original compiled modules. The 85 direct edges of the saved breadth-first tree have the same endpoints there.

The optional arguments may be used separately or together.

    python verify.py --tree PATH/TO/evidence/rh-dependency-tree.tsv.gz
    python verify.py --sources WORKSPACE
    python verify.py --cache CACHE
    python verify.py --archive PATH/TO/solution.ndjson.zst

WORKSPACE contains lean/src from the pinned project. CACHE contains modules.jsonl.gz, objects/ with the pinned LTARs and lean-4.33.1-windows/bin with upstream Lean and leantar. The module check re-extracts the matching original modules and reads their complete values with ReadEdges.lean. The optional whole-export check requires Python zstandard and reads the complete compressed archive. The paper's finite arithmetic example can be reproduced separately with verification/check_zeta_jd_example.py.

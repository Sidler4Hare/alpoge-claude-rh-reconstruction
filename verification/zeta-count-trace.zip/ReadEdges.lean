import Lean

open Lean

def main (args : List String) : IO Unit := do
  let [plan, dest] := args | throw (IO.userError "expected module list and output")
  let out ← IO.FS.Handle.mk dest .write
  for line in (← IO.FS.lines plan) do
    let [module, path] := line.splitOn "\t" | throw (IO.userError "invalid plan")
    let (md, _) ← readModuleData path
    for ci in md.constants do
      let vs := (ci.value? (allowOpaque := true)).map (fun expr => expr.getUsedConstants.map Name.toString)
      out.putStrLn (Json.mkObj [("owner", toJson module), ("name", toJson ci.name.toString),
        ("type", toJson (ci.type.getUsedConstants.map Name.toString)), ("value", toJson vs)]).compress
